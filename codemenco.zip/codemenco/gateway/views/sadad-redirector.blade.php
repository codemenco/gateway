<html>
    <body>
        {!! $form !!}
        <br />
        <script type="text/javascript">
            document.getElementById('paymentUTLfrm').submit();
        </script>
        </form>
    </body>
</html>
