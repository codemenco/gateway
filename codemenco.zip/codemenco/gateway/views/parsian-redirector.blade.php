<form action="{!! $url !!}" method="post" id="parsian_gateway"></form>

<script type="text/javascript">
	var f=document.getElementById('parsian_gateway');
	f.submit();
</script>
