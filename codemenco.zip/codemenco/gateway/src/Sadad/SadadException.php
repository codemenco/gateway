<?php

namespace Codemenco\Gateway\Sadad;


use Codemenco\Gateway\Exceptions\BankException;

class SadadException extends BankException {}
