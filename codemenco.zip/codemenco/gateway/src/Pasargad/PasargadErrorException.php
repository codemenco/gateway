<?php

namespace Codemenco\Gateway\Pasargad;

use Codemenco\Gateway\Exceptions\BankException;

class PasargadErrorException extends BankException {}
