<?php

namespace Codemenco\Gateway\Parsian;

use Codemenco\Gateway\Exceptions\BankException;

class ParsianErrorException extends BankException {}
